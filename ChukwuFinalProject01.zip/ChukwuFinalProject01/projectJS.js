// get button input from document, add event listeners to call respective function when clicked
document.getElementById('submit').addEventListener('click', createMealPlan);
document.getElementById('print').addEventListener('click', printMealPlan);
document.getElementById('download').addEventListener('click', downloadMealPlan);

let generatedMealPlan = ''; // initialize empty string to store generatedMealPlan

// fuction to create a weekly meal plan
function createMealPlan() {
    let regex = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/; // regex to validate email format
    let email = document.getElementById('email'); // get email input from document, assign to email variable

    // validate email input value, else alert user 
    if (!regex.test(email.value)) {
        window.alert('Please provide a valid email address');
        return;
    }

    // get value of name and goal input from document, assign to respective variable
    let name = document.getElementById('name').value;
    let goal = document.getElementById('goal').value;

    // get value of meals input for each respective key, store in meals dictionary
    let meals = {
        breakfast: document.getElementById('meal1').value,
        snack1: document.getElementById('meal2').value,
        lunch: document.getElementById('meal3').value,
        snack2: document.getElementById('meal4').value,
        dinner: document.getElementById('meal5').value,
    };

    // assign HTML structure for weekly meal plan to generatedMealPlan variable
    generatedMealPlan = `
        <html>
            <head>
                <title>${name}'s Weekly Meal Plan</title> 
                
                <!-- styling properties for table cells appearance / layout -->
                <style>
                    body { font-family: Arial, sans-serif; line-height: 1.6; text-align: center; }
                    table { width: 80%; margin: auto; border-collapse: collapse; }
                    th, td { border: 1px solid #ddd; padding: 8px; text-align: center; }
                    th { background-color: #f4f4f4; }
                </style>
            </head>
            <body>
                <h1>${name}'s Weekly Meal Plan</h1> 
                <h2>Goal: ${goal}</h2>
                <table>
                    <tr>
                        <th>Day</th>
                        <th>Breakfast</th>
                        <th>Snack 1</th>
                        <th>Lunch</th>
                        <th>Snack 2</th>
                        <th>Dinner</th>
                    </tr>
                    ${['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday']
            
            // use map function to iterate over array of days
            .map(
                (day) => `
                            <tr>
                                <td>${day}</td>
                                <td>${meals.breakfast}</td>
                                <td>${meals.snack1}</td>
                                <td>${meals.lunch}</td>
                                <td>${meals.snack2}</td>
                                <td>${meals.dinner}</td>
                            </tr>`
            )
            // combine all rows generated into one string
            .join('')}
                </table>
            </body>
        </html>
    `;

    // open new window and write generated meal plan, assign to newWindow variable
    let newWindow = window.open('', '_blank');
    newWindow.document.write(generatedMealPlan);
    newWindow.document.close();
}

// function to print generated meal plan
function printMealPlan() {
    // check if meal plan content provided, else alert user
    if (generatedMealPlan) {
        // write in new open window to print, assign to printWindow variable
        let printWindow = window.open('', '_blank');
        printWindow.document.write(generatedMealPlan);
        printWindow.document.close();
        printWindow.print(); // trigger print pop up
    } else {
        alert('Please create a meal plan first.');
    }
}

// function to download generated meal plan as HTML file
function downloadMealPlan() {
    // check if meal plan content created, else alert user
    if (generatedMealPlan) { 
        // cast meal plan content array and data type to blob, assign to blob variable
        let blob = new Blob([generatedMealPlan], { type: 'text/html' });
        let url = URL.createObjectURL(blob); // create URL, assign to blob
        let a = document.createElement('a'); // create anchor element for downloading
        a.href = url; // set Blob URL as href
        a.download = 'meal_plan.html'; // set the filename for the download
        document.body.appendChild(a); // append the anchor to body of document
        a.click(); // click anchor to start download
        document.body.removeChild(a); // remove anchor from the document
    } else {
        alert('Please create a meal plan first.');
    }
}